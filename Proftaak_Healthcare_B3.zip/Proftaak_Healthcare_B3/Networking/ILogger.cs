﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Networking
{
    public interface ILogger
    {
        void Log(string text);
    }
}
